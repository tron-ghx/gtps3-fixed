# GTPS3 - Leaked Source
I heard Vyte is looking for fans to become a famous person by collab with any server & using his source, so I want to share his source here with the hope that you don't need to look for people to make your server look good & you should try to find ways to make people interested in playing on your server.


Oh one more secret, ***😝he uses fake online on every server including GTPS3*** itself.
I also fixed the issue of skids duplicating.

[GTPS3 Admin Panel](https://github.com/tron-ghx/gtps3-admin-panel)
**selling leaked source is a human failure**
# My Opinion
My opinion about this source, a lot of unstable code but still usable, some bugs may still exist but I don't look for it because it just waste my time so you have to fix it by yourself (Make great effort and stop constantly depending on other person)... one more thing.... Vyte skill issues😛
😝

# Our community & what we do
- GHX: We like to tell interesting stories about how anything done in this world is POSSIBLE, nothing is impossible.
https://discord.gg/se5Qkf4hmu

## Credits
- [nlohmann/json](https://github.com/nlohmann/json): C++ library for manipulating JSON data with a "modern C++" design.
- [ENet Networking Library](https://github.com/lsalzman/enet): Networking library for game development with support for peer-to-peer communication and server-based connection management.
